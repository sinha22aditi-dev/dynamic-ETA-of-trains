# 23-language UI set = English + India's 22 Scheduled Languages.
LANGUAGES={
 "en":"English","hi":"Hindi","as":"Assamese","bn":"Bengali","brx":"Bodo","doi":"Dogri",
 "gu":"Gujarati","kn":"Kannada","ks":"Kashmiri","kok":"Konkani","mai":"Maithili","ml":"Malayalam",
 "mni":"Manipuri","mr":"Marathi","ne":"Nepali","or":"Odia","pa":"Punjabi","sa":"Sanskrit",
 "sat":"Santali","sd":"Sindhi","ta":"Tamil","te":"Telugu","ur":"Urdu"
}

LABELS={
 "en":{"eta":"Estimated arrival","delay":"Current delay","reason":"Delay reason","risk":"Propagation risk"},
 "hi":{"eta":"अनुमानित आगमन","delay":"वर्तमान देरी","reason":"देरी का कारण","risk":"देरी फैलने का जोखिम"},
 "bn":{"eta":"আনুমানিক আগমন","delay":"বর্তমান বিলম্ব","reason":"বিলম্বের কারণ","risk":"বিলম্ব ছড়ানোর ঝুঁকি"},
 "mr":{"eta":"अंदाजे आगमन","delay":"सध्याचा विलंब","reason":"विलंबाचे कारण","risk":"विलंब पसरण्याचा धोका"},
 "gu":{"eta":"અંદાજિત આગમન","delay":"વર્તમાન વિલંબ","reason":"વિલંબનું કારણ","risk":"વિલંબ ફેલાવાનું જોખમ"},
 "ta":{"eta":"மதிப்பிடப்பட்ட வருகை","delay":"தற்போதைய தாமதம்","reason":"தாமத காரணம்","risk":"தாமதம் பரவும் அபாயம்"},
 "te":{"eta":"అంచనా రాక సమయం","delay":"ప్రస్తుత ఆలస్యం","reason":"ఆలస్యానికి కారణం","risk":"ఆలస్యం వ్యాపించే ప్రమాదం"},
 "kn":{"eta":"ಅಂದಾಜು ಆಗಮನ","delay":"ಪ್ರಸ್ತುತ ವಿಳಂಬ","reason":"ವಿಳಂಬದ ಕಾರಣ","risk":"ವಿಳಂಬ ಹರಡುವ ಅಪಾಯ"},
 "ml":{"eta":"കണക്കാക്കിയ വരവ്","delay":"നിലവിലെ വൈകിപ്പ്","reason":"വൈകിപ്പിന്റെ കാരണം","risk":"വൈകിപ്പ് പകരാനുള്ള അപകടസാധ്യത"},
 "pa":{"eta":"ਅਨੁਮਾਨਿਤ ਪਹੁੰਚ","delay":"ਮੌਜੂਦਾ ਦੇਰੀ","reason":"ਦੇਰੀ ਦਾ ਕਾਰਨ","risk":"ਦੇਰੀ ਫੈਲਣ ਦਾ ਖਤਰਾ"},
 "or":{"eta":"ଆନୁମାନିକ ପହଞ୍ଚ","delay":"ବର୍ତ୍ତମାନ ବିଳମ୍ବ","reason":"ବିଳମ୍ବର କାରଣ","risk":"ବିଳମ୍ବ ପ୍ରସାରଣ ଝୁମ୍କି"},
}

def labels(lang="en"):
    return LABELS.get(lang,LABELS["en"])

def available_languages(): return [{"code":k,"name":v} for k,v in LANGUAGES.items()]

def chatbot_reply(query, prediction, lang="en"):
    q=query.lower().strip()
    if any(x in q for x in ["why","reason","kyun","क्यों","karan","कारण"]):
        return prediction.get("delay_reason", "Delay reason is not available.")
    if any(x in q for x in ["how late","delay","late","kitni","देर"]):
        return f"Current delay: {prediction.get('current_delay_mins',0):.0f} minutes. Predicted additional delay: {prediction.get('predicted_additional_delay_mins',0):.0f} minutes."
    if any(x in q for x in ["eta","arrival","arrive","kab","कब"]):
        return f"Estimated arrival: {prediction.get('eta','Not available')} (interval: {prediction.get('eta_interval',{}).get('lower','')} to {prediction.get('eta_interval',{}).get('upper','')})."
    if any(x in q for x in ["another train","other train","propagation","affected","impact"]):
        p=prediction.get("propagation",{}); return f"Potential propagation risk: {p.get('risk','UNKNOWN')} with probability {p.get('probability',0):.0%}."
    return "I can help with ETA, current delay, delay reason, and possible impact on other trains."
